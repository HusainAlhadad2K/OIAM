Import this profile in bitvise to load all ports used.

VNC:
port 5901
vnc password: vncpasswd


To access the integrated application:
http://localhost:7777/

Credentials
Use the created user in order to login and try the MFA

To access OAM 
Homepage:
http://127.0.0.1:7001/oamconsole

Credentials:
weblogic_idm
BestTeam##2024

WebLogic:
http://localhost:7001/console
Entreprise Manager:
http://localhost:7001/em

Credentials for both: 
weblogic
BestTeam##2024


To access OIM 
Homepage:
http://127.0.0.1:14000/identity

Credentials:
xelsysadm
BestTeam##2024

WebLogic:
http://localhost:8001/console
Entreprise Manager:
http://localhost:8001/em

Credentials for both: 
weblogic
BestTeam##2024


