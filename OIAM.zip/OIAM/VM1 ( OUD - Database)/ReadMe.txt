Import this profile in bitvise to load all ports used.

VNC:
port 5902
vnc password: vncpasswd

To access OUDSM 
Homepage:
http://localhost:7001/oudsm

Connection:
Server: localhost
Administration Port: 4444
User Name: cn=Directory Manager
Password: BestTeam##2024

WebLogic:
http://localhost:7001/console
Entreprise Manager:
http://localhost:7001/em

Credentials for both: 
weblogic
BestTeam##2024